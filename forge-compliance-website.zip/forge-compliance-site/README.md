# Forge Compliance website

A static, responsive website ready for free hosting with GitHub Pages.

## Publish with GitHub Pages

1. Sign in to GitHub and create a new public repository called `forge-compliance`.
2. Upload every file and folder from this package to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. GitHub will provide a free address such as `https://yourusername.github.io/forge-compliance/`.

## Connect your domain

When you buy `forgecompliance.co.uk`, add it under **Settings → Pages → Custom domain**. GitHub will show the DNS records required by your domain provider.

## Email setup

Free receiving option:

1. Add the domain to Cloudflare.
2. Enable **Email Routing**.
3. Create `hello@forgecompliance.co.uk` and forward it to your normal inbox.
4. Verify the destination inbox.

Cloudflare routing receives and forwards mail but does not provide a full mailbox for sending. For reliable sending from the branded address, use a paid mailbox later, such as Microsoft 365, Google Workspace, Zoho Mail or your domain provider's email service.

## Important edits before launch

- Replace the placeholder email in `assets/script.js` if needed.
- Confirm pricing.
- Add your telephone number only when you want it public.
- Have the privacy policy and terms reviewed once hosting, payment, analytics and email providers are confirmed.
- Add real document previews and checkout after the initial launch.
